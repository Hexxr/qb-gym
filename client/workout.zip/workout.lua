local isWorkingOut = false

local function GetWorkoutData(workoutType, key)
    local pool = Config[workoutType]
    return pool and pool[key]
end

RegisterNetEvent('qb-gym:startWorkout', function(workoutType, key)
    print('StartWorkout triggered for:', workoutType, key)

    if isWorkingOut then
        print('Workout already active — blocking duplicate trigger')
        return
    end

    local workout = GetWorkoutData(workoutType, key)
    print('DEBUG WORKOUT DATA:', json.encode(workout))

    if not workout or type(workout.animDict) ~= 'string' or workout.animDict == '' then
        print('ERROR: Invalid or missing animDict', workout and workout.animDict)
        lib.notify({ type = 'error', description = 'Invalid workout animation' })
        return
    end

    if type(workout.anim) ~= 'string' or workout.anim == '' then
        print('ERROR: Invalid or missing animation name', workout and workout.anim)
        lib.notify({ type = 'error', description = 'Invalid workout animation' })
        return
    end

    isWorkingOut = true

    local ped = PlayerPedId()
    local propEntity

    -- Skill Check
    local success = lib.skillCheck({ workout.difficulty or 'easy' }, { 'w', 'a', 's', 'd' })
    if not success then
        lib.notify({ type = 'error', title = 'Workout', description = 'Failed the set.' })
        isWorkingOut = false
        return
    end

    print('REQUESTING ANIM:', workout.animDict, 'TYPE:', type(workout.animDict))

    -- Load Anim
    lib.requestAnimDict(workout.animDict)

    -- Load Prop if needed
    if workout.prop then
        local propHash = joaat(workout.prop)
        lib.requestModel(propHash)
        local coords = GetEntityCoords(ped)
        propEntity = CreateObject(propHash, coords.x, coords.y, coords.z + 0.2, true, true, true)
        AttachEntityToEntity(propEntity, ped, GetPedBoneIndex(ped, 57005), 0.1, 0.0, -0.02, 90.0, 90.0, 0.0, true, true, false, true, 1, true)
    end

    -- Animation
    lib.playAnim({
        dict = workout.animDict,
        anim = workout.anim,
        flag = 49,
        duration = 3000
    })

    -- Progress
    lib.progressBar({
        duration = 5000,
        label = workout.label or 'Working out...',
        useWhileDead = false,
        canCancel = false,
        disable = { move = true, car = true, combat = true },
    })

    -- Cleanup
    if propEntity and DoesEntityExist(propEntity) then
        DetachEntity(propEntity, true, true)
        DeleteEntity(propEntity)
    end

    -- Reward logic
    TriggerServerEvent('qb-gym:reward', workout.stat or 'strength')
    lib.notify({ type = 'success', title = 'Workout', description = 'You feel stronger!' })

    isWorkingOut = false
end)